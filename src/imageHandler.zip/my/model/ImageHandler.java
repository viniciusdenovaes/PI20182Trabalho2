package my.model;

import java.awt.image.BufferedImage;
import java.awt.image.Raster;

public class ImageHandler {
  public static Cor[][] getMatrizImagemColorida(BufferedImage image) {
    int altura = image.getHeight();
    int largura = image.getWidth();
    Raster raster = image.getData();
    Cor[][] matrizDaImagem = new Cor[largura][altura];
    for(int x=0; x<largura; ++x) {
      for(int y=0; y<altura; ++y) {
        matrizDaImagem[x][y] = new Cor(raster.getSample(x, y, 0), 
                                         raster.getSample(x, y, 1), 
                                         raster.getSample(x, y, 2) );
      }
    }
    
    return matrizDaImagem;
  }
  public static int[][] getMatrizImagemCinza(BufferedImage image) {
    int altura = image.getHeight();
    int largura = image.getWidth();
    Raster raster = image.getData();
    int[][] matrizDaImagem = new int[largura][altura];
    for(int x=0; x<largura; ++x) {
      for(int y=0; y<altura; ++y) {
        matrizDaImagem[x][y] = raster.getSample(x, y, 0);
      }
    }
    
    return matrizDaImagem;
  }
  public static BufferedImage getImageFromMatriz(Cor[][] matrizDaImagem) {
    if(matrizDaImagem.length<1 || matrizDaImagem[0].length<1)
      throw new RuntimeException("ERRO: em ImageHandler.printImage, matriz da imagem vazia");
    int largura = matrizDaImagem.length;
    int altura = matrizDaImagem[0].length;
    BufferedImage image = new BufferedImage(largura, 
                                            altura, 
                                            BufferedImage.TYPE_INT_RGB);
    for(int x=0; x<largura; ++x) {
      for(int y=0; y<altura; ++y) {
        int rgb = matrizDaImagem[x][y].r;
        rgb = (rgb<<8) + matrizDaImagem[x][y].g;
        rgb = (rgb<<8) + matrizDaImagem[x][y].b;
        image.setRGB(x, y, rgb);
      }
    }
    return image;
  }
}
