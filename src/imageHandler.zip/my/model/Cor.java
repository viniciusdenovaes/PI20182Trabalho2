package my.model;

public class Cor {
  public int r, g, b;
  public Cor(int aRed, int aGreen, int aBlue) {
    this.r = aRed;
    this.g = aGreen;
    this.b = aBlue;
  }
  
  @Override
  public String toString() {
    String res = "";
    res = "(" + this.r + ", "+
                this.g + ", "+
                this.b + ")";
    return res;
  }
  public void set(int c) {
    c = Integer.min(255, c);
    c = Integer.max(0, c);
    this.r = 
    this.g = 
    this.b = c;
  }
}
