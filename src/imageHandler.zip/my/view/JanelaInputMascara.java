package my.view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

@SuppressWarnings("serial")
public class JanelaInputMascara extends JFrame{
  JTextField[][] mascaraInput;
  JTextField     escalarInput;
  public static final int TAMANHO_MASCARA = 3;
  public JanelaInputMascara(ActionListener al) {
    super("Entrada Máscara");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    JPanel painelCentral = new JPanel();
    painelCentral.setLayout(new GridLayout(3,3));
    mascaraInput = new JTextField[TAMANHO_MASCARA][TAMANHO_MASCARA];
    for(int x=0; x<TAMANHO_MASCARA; ++x) {
      for(int y=0; y<TAMANHO_MASCARA; ++y) {
        mascaraInput[x][y] = new JTextField(3);
        painelCentral.add(mascaraInput[x][y]);
      }
    }
    
    JPanel painelEscalar = new JPanel();
    escalarInput = new JTextField(3);
    painelEscalar.add(escalarInput);
    
    JPanel painelBotao = new JPanel();
    JButton botao = new JButton("Passar Máscara");
    botao.addActionListener(al);
    painelBotao.add(botao);
    
    setLayout(new BorderLayout());
    add(painelCentral, BorderLayout.CENTER);
    add(painelEscalar, BorderLayout.WEST);
    add(painelBotao, BorderLayout.SOUTH);
    
    pack();
    setVisible(true);
  }
  
  public double[][] getMascaraValor(){
    double[][] mascaraValor = new double[TAMANHO_MASCARA][TAMANHO_MASCARA];
    for(int y=0; y<TAMANHO_MASCARA; ++y) {
      for(int x=0; x<TAMANHO_MASCARA; ++x) {
        mascaraValor[x][y] = JanelaInputMascara.
                             getValorEscrito(mascaraInput[x][y].getText());
      }
    }
    return mascaraValor;
  }
  
  public double getEscalarValor() {
    return JanelaInputMascara.
           getValorEscrito(escalarInput.getText());
  }
  
  private static double getValorEscrito(String valorEscrito) {
    double valor;
    valorEscrito = valorEscrito.replaceAll(" ", "");
    if(valorEscrito.equals(""))
      valor = 0;
    else 
      valor = Double.parseDouble(valorEscrito);
    return valor;
  }

}
