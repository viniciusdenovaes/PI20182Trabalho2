package my.view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

@SuppressWarnings("serial")
public class JanelaInputMascara extends JFrame{
  JTextField[][] mascaraInput;
  JTextField     escalarInput;
  public static final int TAMANHO_MASCARA = 3;
  public JanelaInputMascara(ActionListener al) {
    super("Entrada Máscara");
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    JPanel painelCentral = new JPanel();
    painelCentral.setLayout(new GridLayout(3,3));
    mascaraInput = new JTextField[TAMANHO_MASCARA][TAMANHO_MASCARA];
    for(int i=0; i<TAMANHO_MASCARA; ++i) {
      for(int j=0; j<TAMANHO_MASCARA; ++j) {
        mascaraInput[i][j] = new JTextField(3);
        painelCentral.add(mascaraInput[i][j]);
      }
    }
    
    JPanel painelEscalar = new JPanel();
    escalarInput = new JTextField(3);
    painelEscalar.add(escalarInput);
    
    JPanel painelBotao = new JPanel();
    JButton botao = new JButton("Passar Máscara");
    botao.addActionListener(al);
    
    setLayout(new BorderLayout());
    add(painelCentral, BorderLayout.CENTER);
    add(painelEscalar, BorderLayout.WEST);
    add(painelBotao, BorderLayout.SOUTH);
    
    pack();
    setVisible(true);
  }
  
  double[][] getMascaraValor(){
    double[][] mascaraValor = new double[TAMANHO_MASCARA][TAMANHO_MASCARA];
    for(int i=0; i<TAMANHO_MASCARA; ++i) {
      for(int j=0; j<TAMANHO_MASCARA; ++j) {
        String valorEscrito = mascaraInput[i][j].getText();
        double valor;
        if(valorEscrito.equals(""))
          valor = 0;
        else 
          valor = Double.parseDouble(valorEscrito);
        mascaraValor[i][j] = valor;
      }
    }
    return mascaraValor;
  }
  
  double getEscalarValor() {
    return Double.parseDouble(escalarInput.getText());
  }
  
  private static double getValorEscrito(String valorEscrito) {
    double valor;
    valorEscrito = valorEscrito.replaceAll(" ", "");
    if(valorEscrito.equals(""))
      valor = 0;
    else 
      valor = Double.parseDouble(valorEscrito);
    return valor;
  }

}
