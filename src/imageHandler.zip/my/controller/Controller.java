package my.controller;

import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import my.model.Cor;
import my.model.ImageHandler;
import my.view.GetImageFrame;
import my.view.JanelaImagem;
import my.view.JanelaInputMascara;

public class Controller {
  JanelaInputMascara janelaInputMascara;
  JanelaImagem janelaImagemEntrada;
  BufferedImage imagemEntrada;
  public Controller(ActionListener al) {
    janelaInputMascara = new JanelaInputMascara(al);
    GetImageFrame getImageFrame = new GetImageFrame();
    imagemEntrada = getImageFrame.getImage();
    janelaImagemEntrada = new JanelaImagem(imagemEntrada, 
                                           "Janela Imagem Entrada");
        
  }
  
  public double[][] getMascara(){
    return janelaInputMascara.getMascaraValor();
  }
  public double getEscalar() {
    return janelaInputMascara.getEscalarValor();
  }
  public Cor[][] getMatrizImagemEntrada(){
    return ImageHandler.getMatrizImagemColorida(this.imagemEntrada);
  }
  public void showImagemFromMatriz(Cor[][] matriz) {
    BufferedImage imagemResultado = ImageHandler.getImageFromMatriz(matriz);
    JanelaImagem janelaImagem = new JanelaImagem(imagemResultado, 
                                                 "Imagem Resultado");
    janelaImagem.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  }
  

}
